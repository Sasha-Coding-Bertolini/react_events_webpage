// import React, { useEffect, useState } from "react";
// import {
//   Heading,
//   Text,
//   Image,
//   Button,
//   FormControl,
//   FormLabel,
//   Input,
//   AlertDialog,
//   AlertDialogBody,
//   AlertDialogFooter,
//   AlertDialogHeader,
//   AlertDialogContent,
//   AlertDialogOverlay,
//   Box,
//   Center,
// } from "@chakra-ui/react";
// import { useParams, useNavigate } from "react-router-dom";
// import { toast, ToastContainer } from "react-toastify";
// import "react-toastify/dist/ReactToastify.css";

// export const EventPage = () => {
//   const navigate = useNavigate();
//   const { eventId } = useParams();
//   const [event, setEvent] = useState(null);
//   const [categories, setCategories] = useState([]);
//   const [users, setUsers] = useState([]);
//   const [isEditing, setIsEditing] = useState(false);
//   const [editedEvent, setEditedEvent] = useState({});
//   const [isConfirmationOpen, setIsConfirmationOpen] = useState(false);
//   const [isModalOpen, setIsModalOpen] = useState(false);

//   useEffect(() => {
//     // Fetch event details based on the eventId
//     const fetchEvent = async () => {
//       try {
//         const response = await fetch(`http://localhost:3000/events/${eventId}`);
//         const eventData = await response.json();
//         setEvent(eventData);
//       } catch (error) {
//         console.log("Error fetching event details:", error);
//       }
//     };

//     fetchEvent();
//   }, [eventId]);

//   useEffect(() => {
//     const fetchCategories = async () => {
//       const response = await fetch("http://localhost:3000/categories");
//       const data = await response.json();
//       setCategories(data);
//     };
//     fetchCategories();
//   }, []);

//   useEffect(() => {
//     const fetchUsers = async () => {
//       const response = await fetch("http://localhost:3000/users");
//       const data = await response.json();
//       setUsers(data);
//     };
//     fetchUsers();
//   }, []);

//   if (!event) {
//     return (
//       <Center minHeight="100vh">
//         <Text>Loading...</Text>
//       </Center>
//     );
//   }

//   const {
//     title,
//     image,
//     description,
//     startTime,
//     endTime,
//     categoryIds,
//     createdBy,
//   } = isEditing ? editedEvent : event;

//   const getCategoryNames = (eventCategoryIds) => {
//     const eventCategories = eventCategoryIds.map((categoryId) =>
//       categories.find((category) => category.id === categoryId)
//     );
//     return eventCategories.map((category) => category?.name || "").join(", ");
//   };

//   const getUserNames = (eventCreatedBy) => {
//     const user = users.find((user) => user.id === eventCreatedBy);
//     return user?.name || "";
//   };

//   const getUserImage = (eventCreatedBy) => {
//     const user = users.find((user) => user.id === eventCreatedBy);
//     return user?.image || "";
//   };

//   const handleEditClick = () => {
//     setEditedEvent(event);
//     setIsModalOpen(true); // Open the editing modal
//   };

//   const handleCancelClick = () => {
//     setIsEditing(false);
//     setIsModalOpen(false); // Close the editing modal
//   };

//   const handleInputChange = (e) => {
//     const { name, value } = e.target;
//     setEditedEvent((prevEvent) => ({
//       ...prevEvent,
//       [name]: value,
//     }));
//   };

//   const handleFormSubmit = async (e) => {
//     e.preventDefault();
//     try {
//       const response = await fetch(`http://localhost:3000/events/${eventId}`, {
//         method: "PUT",
//         headers: {
//           "Content-Type": "application/json",
//         },
//         body: JSON.stringify(editedEvent),
//       });
//       if (response.ok) {
//         const updatedEventData = await response.json();
//         setEvent(updatedEventData);
//         setIsEditing(false);
//         setIsModalOpen(false); // Close the editing modal
//         toast.success("Event updated successfully!", {
//           position: toast.POSITION.BOTTOM_RIGHT,
//         });
//       } else {
//         console.log(
//           "Error updating event:",
//           response.status,
//           response.statusText
//         );
//         toast.error("Error updating event...", {
//           position: toast.POSITION.BOTTOM_RIGHT,
//         });
//       }
//     } catch (error) {
//       console.log("Error updating event:", error);
//     }
//   };

//   const handleDeleteClick = () => {
//     setIsConfirmationOpen(true);
//   };

//   const handleDeleteConfirmation = async () => {
//     try {
//       const eventResponse = await fetch(
//         `http://localhost:3000/events/${eventId}`
//       );

//       if (eventResponse.ok) {
//         const eventData = await eventResponse.json();
//         const userId = eventData.createdBy;
//         console.log(userId);

//         const response = await fetch(
//           `http://localhost:3000/events/${eventId}`,
//           {
//             method: "DELETE",
//           }
//         );

//         if (response.ok) {
//           toast.success("Event deleted successfully!", {
//             position: toast.POSITION.BOTTOM_RIGHT,
//           });

//           const allEventsResponse = await fetch(`http://localhost:3000/events`);
//           const allEventsData = await allEventsResponse.json();
//           const createdByList = allEventsData.map((event) => event.createdBy);
//           console.log(createdByList);

//           if (!createdByList.includes(userId)) {
//             const userResponse = await fetch(
//               `http://localhost:3000/users/${userId}`,
//               {
//                 method: "DELETE",
//               }
//             );

//             if (userResponse.ok) {
//               console.log("Deleted user.");
//             } else {
//               console.log(
//                 "Error deleting user.",
//                 userResponse.status,
//                 userResponse.statusText
//               );
//               toast.error("Error deleting user...", {
//                 position: toast.POSITION.BOTTOM_RIGHT,
//               });
//             }
//           }

//           const searchParams = new URLSearchParams();
//           searchParams.append("toast", "Event deleted successfully!");
//           navigate({
//             pathname: "/",
//             search: `?${searchParams.toString()}`,
//           });
//         } else {
//           console.log(
//             "Error deleting event:",
//             response.status,
//             response.statusText
//           );
//           toast.error("Error deleting event...", {
//             position: toast.POSITION.BOTTOM_RIGHT,
//           });
//         }
//       } else {
//         console.log("Event not found:", eventResponse.status);
//         toast.error("Event not found...", {
//           position: toast.POSITION.BOTTOM_RIGHT,
//         });
//       }
//     } catch (error) {
//       console.log("Error deleting event:", error);
//     }
//   };

//   const handleCloseConfirmation = () => {
//     setIsConfirmationOpen(false);
//   };

//   const renderEventDetails = () => {
//     if (isEditing) {
//       return (
//         <form onSubmit={handleFormSubmit}>
//           <FormControl mb={4}>
//             <FormLabel>Title</FormLabel>
//             <Input
//               type="text"
//               name="title"
//               value={editedEvent.title}
//               onChange={handleInputChange}
//             />
//           </FormControl>
//           <FormControl mb={4}>
//             <FormLabel>Description</FormLabel>
//             <Input
//               type="text"
//               name="description"
//               value={editedEvent.description}
//               onChange={handleInputChange}
//             />
//           </FormControl>
//           <FormControl mb={4}>
//             <FormLabel>Start Time</FormLabel>
//             <Input
//               type="text"
//               name="startTime"
//               value={editedEvent.startTime}
//               onChange={handleInputChange}
//             />
//           </FormControl>
//           <FormControl mb={4}>
//             <FormLabel>End Time</FormLabel>
//             <Input
//               type="text"
//               name="endTime"
//               value={editedEvent.endTime}
//               onChange={handleInputChange}
//             />
//           </FormControl>
//           <Button onClick={handleCancelClick}>Cancel</Button>{" "}
//           {/* Use handleCancelClick for cancel */}
//           <Button type="submit">Save</Button>
//         </form>
//       );
//     } else {
//       return (
//         <>
//           <Heading>{title}</Heading>
//           <Center>
//             <Image
//               margin="5"
//               borderRadius="20"
//               boxSize="300px"
//               src={image}
//               alt="Event Image"
//             />
//           </Center>
//           <Text>{description}</Text>
//           <Text>Start Time: {startTime}</Text>
//           <Text>End Time: {endTime}</Text>
//           <Text>Category: {getCategoryNames(categoryIds)}</Text>
//           <Text>Created By: {getUserNames(createdBy)}</Text>
//           <Image
//             margin="5"
//             borderRadius="20"
//             boxSize="300px"
//             src={getUserImage(createdBy)}
//             alt="Event Image"
//           />
//           <Button onClick={handleEditClick}>Edit</Button>{" "}
//           {/* Use handleEditClick for edit */}
//           <Button colorScheme="red" onClick={handleDeleteClick}>
//             Delete
//           </Button>
//         </>
//       );
//     }
//   };

//   return (
//     <Box p={4}>
//       <ToastContainer />
//       {renderEventDetails()}
//       <AlertDialog
//         isOpen={isConfirmationOpen}
//         leastDestructiveRef={undefined}
//         onClose={handleCloseConfirmation}
//       >
//         <AlertDialogOverlay>
//           <AlertDialogContent>
//             <AlertDialogHeader fontSize="lg" fontWeight="bold">
//               Delete Event
//             </AlertDialogHeader>

//             <AlertDialogBody>
//               Are you sure you want to delete this event? This action is
//               irreversible.
//             </AlertDialogBody>

//             <AlertDialogFooter>
//               <Button onClick={handleCloseConfirmation}>Cancel</Button>
//               <Button
//                 colorScheme="red"
//                 onClick={handleDeleteConfirmation}
//                 ml={3}
//               >
//                 Delete
//               </Button>
//             </AlertDialogFooter>
//           </AlertDialogContent>
//         </AlertDialogOverlay>
//       </AlertDialog>
//       <AlertDialog
//         isOpen={isModalOpen}
//         leastDestructiveRef={undefined}
//         onClose={handleCancelClick}
//       >
//         <AlertDialogOverlay>
//           <AlertDialogContent>
//             <AlertDialogHeader>Edit Event</AlertDialogHeader>
//             <AlertDialogBody>
//               <form onSubmit={handleFormSubmit}>
//                 <FormControl mb={4}>
//                   <FormLabel>Title</FormLabel>
//                   <Input
//                     type="text"
//                     name="title"
//                     value={editedEvent.title}
//                     onChange={handleInputChange}
//                   />
//                 </FormControl>
//                 <FormControl mb={4}>
//                   <FormLabel>Description</FormLabel>
//                   <Input
//                     type="text"
//                     name="description"
//                     value={editedEvent.description}
//                     onChange={handleInputChange}
//                   />
//                 </FormControl>
//                 <FormControl mb={4}>
//                   <FormLabel>Start Time</FormLabel>
//                   <Input
//                     type="text"
//                     name="startTime"
//                     value={editedEvent.startTime}
//                     onChange={handleInputChange}
//                   />
//                 </FormControl>
//                 <FormControl mb={4}>
//                   <FormLabel>End Time</FormLabel>
//                   <Input
//                     type="text"
//                     name="endTime"
//                     value={editedEvent.endTime}
//                     onChange={handleInputChange}
//                   />
//                 </FormControl>
//               </form>
//             </AlertDialogBody>
//             <AlertDialogFooter>
//               <Button onClick={handleCancelClick}>Cancel</Button>
//               <Button type="submit" onClick={handleFormSubmit} ml={3}>
//                 Save
//               </Button>
//             </AlertDialogFooter>
//           </AlertDialogContent>
//         </AlertDialogOverlay>
//       </AlertDialog>
//     </Box>
//   );
// };
