// import { useEffect, useState } from "react";
// import React from "react";
// import {
//   Flex,
//   Heading,
//   Image,
//   Text,
//   Button,
//   Modal,
//   ModalOverlay,
//   ModalContent,
//   ModalHeader,
//   ModalBody,
//   ModalFooter,
//   FormControl,
//   FormLabel,
//   Input,
//   Checkbox,
// } from "@chakra-ui/react";
// import { Link } from "react-router-dom";
// import { toast, ToastContainer } from "react-toastify";
// import "react-toastify/dist/ReactToastify.css";

// export const EventsPage = () => {
//   const [events, setEvents] = useState([]);
//   const [categories, setCategories] = useState([]);
//   const [isModalOpen, setIsModalOpen] = useState(false);
//   const [newEvent, setNewEvent] = useState({
//     userImage: "",
//     createdBy: "",
//     title: "",
//     image: "",
//     description: "",
//     startTime: "",
//     endTime: "",
//     categoryIds: [],
//   });
//   const [searchTerm, setSearchTerm] = useState("");
//   const [selectedCategories, setSelectedCategories] = useState([]);

//   useEffect(() => {
//     const fetchEvents = async () => {
//       const response = await fetch("http://localhost:3000/events");
//       const data = await response.json();
//       setEvents(data);
//     };
//     fetchEvents();
//   }, []);

//   useEffect(() => {
//     const fetchCategories = async () => {
//       const response = await fetch("http://localhost:3000/categories");
//       const data = await response.json();
//       setCategories(data);
//     };
//     fetchCategories();
//   }, []);

//   const getCategoryNames = (eventCategoryIds) => {
//     const eventCategories = eventCategoryIds.map((categoryId) =>
//       categories.find((category) => category.id === categoryId)
//     );
//     return eventCategories.map((category) => category?.name || "").join(", ");
//   };

//   const handleModalOpen = () => {
//     setIsModalOpen(true);
//   };

//   const handleModalClose = () => {
//     setIsModalOpen(false);
//   };

//   const handleInputChange = (e) => {
//     const { name, value } = e.target;
//     setNewEvent((prevEvent) => ({
//       ...prevEvent,
//       [name]: value,
//     }));
//   };

//   const handleFormSubmit = async (e) => {
//     e.preventDefault();
//     try {
//       const userData = await fetch("http://localhost:3000/users");
//       const allUserData = await userData.json();
//       const userNameList = allUserData.map((user) => user.name.toLowerCase());
//       console.log(userNameList);

//       const isUserNameExists = userNameList.some(
//         (name) => name === newEvent.createdBy.toLowerCase()
//       );

//       if (isUserNameExists) {
//         const existingUser = allUserData.find(
//           (user) => user.name.toLowerCase() === newEvent.createdBy.toLowerCase()
//         );
//         const userId = existingUser.id;

//         const response = await fetch("http://localhost:3000/events", {
//           method: "POST",
//           headers: {
//             "Content-Type": "application/json",
//           },
//           body: JSON.stringify({
//             ...newEvent,
//             createdBy: userId,
//           }),
//         });

//         if (response.ok) {
//           // Event added successfully, fetch the updated event list here
//           const data = await response.json();
//           console.log("New event added:", data);
//           // Reset the form fields
//           setNewEvent({
//             createdBy: "",
//             title: "",
//             image: "",
//             description: "",
//             startTime: "",
//             endTime: "",
//             categoryIds: [],
//           });
//           // Close the modal
//           setIsModalOpen(false);
//           toast.success("Event added successfully!", {
//             position: toast.POSITION.BOTTOM_RIGHT,
//           });

//           // Fetch the updated list of events
//           const updatedEventsResponse = await fetch(
//             "http://localhost:3000/events"
//           );
//           const updatedEventData = await updatedEventsResponse.json();
//           setEvents(updatedEventData);
//         } else {
//           console.log(
//             "Error adding event.",
//             response.status,
//             response.statusText
//           );
//         }
//       } else {
//         const userResponse = await fetch("http://localhost:3000/users", {
//           method: "POST",
//           headers: {
//             "Content-Type": "application/json",
//           },
//           body: JSON.stringify({
//             name: newEvent.createdBy,
//             image: newEvent.userImage,
//           }),
//         });

//         if (userResponse.ok) {
//           const user = await userResponse.json();

//           const response = await fetch("http://localhost:3000/events", {
//             method: "POST",
//             headers: {
//               "Content-Type": "application/json",
//             },
//             body: JSON.stringify({
//               ...newEvent,
//               createdBy: user.id,
//             }),
//           });

//           if (response.ok) {
//             // Event added successfully, fetch the updated event list here
//             const data = await response.json();
//             console.log("New event added:", data);
//             // Reset the form fields
//             setNewEvent({
//               createdBy: "",
//               title: "",
//               image: "",
//               description: "",
//               startTime: "",
//               endTime: "",
//               categoryIds: [],
//             });
//             // Close the modal
//             setIsModalOpen(false);
//             toast.success("Event added successfully!", {
//               position: toast.POSITION.BOTTOM_RIGHT,
//             });

//             // Fetch the updated list of events
//             const updatedEventsResponse = await fetch(
//               "http://localhost:3000/events"
//             );
//             const updatedEventData = await updatedEventsResponse.json();
//             setEvents(updatedEventData);
//           } else {
//             console.log(
//               "Error adding event:",
//               response.status,
//               response.statusText
//             );
//           }
//         } else {
//           console.log(
//             "Error adding user:",
//             userResponse.status,
//             userResponse.statusText
//           );
//         }
//       }
//     } catch (error) {
//       console.log("Error adding event:", error);
//     }
//   };

//   const handleSearch = (e) => {
//     setSearchTerm(e.target.value);
//   };

//   const handleCategoryFilter = (categoryId) => {
//     setSelectedCategories((prevSelectedCategories) => {
//       if (prevSelectedCategories.includes(categoryId)) {
//         return prevSelectedCategories.filter((id) => id !== categoryId);
//       } else {
//         return [...prevSelectedCategories, categoryId];
//       }
//     });
//   };

//   const isEventMatchSearchTerm = (event) => {
//     return (
//       event.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
//       event.description.toLowerCase().includes(searchTerm.toLowerCase())
//     );
//   };

//   const isEventMatchSelectedCategories = (event) => {
//     if (selectedCategories.length === 0) {
//       return true;
//     } else {
//       return event.categoryIds.some((categoryId) =>
//         selectedCategories.includes(categoryId)
//       );
//     }
//   };

//   const filteredEvents = events.filter(
//     (event) =>
//       isEventMatchSearchTerm(event) && isEventMatchSelectedCategories(event)
//   );

//   return (
//     <div className="App">
//       <>
//         <Flex align="center" justify="space-between" mb={4}>
//           <Heading textAlign="center">List of Events</Heading>
//           <Flex>
//             <FormControl mr={4}>
//               <FormLabel>Search</FormLabel>
//               <Input value={searchTerm} onChange={handleSearch} />
//             </FormControl>
//             <FormControl>
//               <FormLabel>Categories</FormLabel>
//               {categories.map((category) => (
//                 <Checkbox
//                   key={category.id}
//                   value={category.id}
//                   isChecked={selectedCategories.includes(category.id)}
//                   onChange={() => handleCategoryFilter(category.id)}
//                 >
//                   {category.name}
//                 </Checkbox>
//               ))}
//             </FormControl>
//           </Flex>
//         </Flex>
//         <Button onClick={handleModalOpen} my={4} mx="auto" display="block">
//           Add Event
//         </Button>
//         <Flex
//           flexDirection={{ base: "column", md: "row" }}
//           justifyContent="center"
//           flexWrap="wrap"
//         >
//           {filteredEvents.map((event) => (
//             <Flex
//               key={event.id}
//               flexDirection="column"
//               alignItems="center"
//               mx={4}
//               my={2}
//               p={4}
//               bg="gray.100"
//               borderRadius="md"
//               boxShadow="md"
//               width={{ base: "100%", sm: "45%", md: "30%" }}
//               _hover={{ bg: "gray.200", cursor: "pointer" }}
//             >
//               <Link to={`/events/${event.id}`}>
//                 <Image
//                   margin="5"
//                   borderRadius="20"
//                   boxSize="100px"
//                   src={event.image}
//                 />
//                 <Text fontWeight="bold">{event.title}</Text>

//                 <Text>{event.description}</Text>
//                 <Text>{event.startTime}</Text>
//                 <Text>{event.endTime}</Text>
//                 <Text>{getCategoryNames(event.categoryIds)}</Text>
//               </Link>
//             </Flex>
//           ))}
//         </Flex>
//         <Modal isOpen={isModalOpen} onClose={handleModalClose}>
//           <ModalOverlay />
//           <ModalContent>
//             <ModalHeader>Add Event</ModalHeader>
//             <ModalBody>
//               <form onSubmit={handleFormSubmit}>
//                 <FormControl mb={4}>
//                   <FormLabel>Created By</FormLabel>
//                   <Input
//                     name="createdBy"
//                     value={newEvent.createdBy}
//                     onChange={handleInputChange}
//                   />
//                 </FormControl>
//                 <FormControl mb={4}>
//                   <FormLabel>Creator Image URL</FormLabel>
//                   <Input
//                     name="userImage"
//                     value={newEvent.userImage}
//                     onChange={handleInputChange}
//                   />
//                 </FormControl>
//                 <FormControl mb={4}>
//                   <FormLabel>Title</FormLabel>
//                   <Input
//                     name="title"
//                     value={newEvent.title}
//                     onChange={handleInputChange}
//                   />
//                 </FormControl>
//                 <FormControl mb={4}>
//                   <FormLabel>Image URL</FormLabel>
//                   <Input
//                     name="image"
//                     value={newEvent.image}
//                     onChange={handleInputChange}
//                   />
//                 </FormControl>
//                 <FormControl mb={4}>
//                   <FormLabel>Description</FormLabel>
//                   <Input
//                     name="description"
//                     value={newEvent.description}
//                     onChange={handleInputChange}
//                   />
//                 </FormControl>
//                 <FormControl mb={4}>
//                   <FormLabel>Start Time</FormLabel>
//                   <Input
//                     name="startTime"
//                     value={newEvent.startTime}
//                     onChange={handleInputChange}
//                   />
//                 </FormControl>
//                 <FormControl mb={4}>
//                   <FormLabel>End Time</FormLabel>
//                   <Input
//                     name="endTime"
//                     value={newEvent.endTime}
//                     onChange={handleInputChange}
//                   />
//                 </FormControl>
//                 <FormControl mb={4}>
//                   <FormLabel>Categories</FormLabel>
//                   {categories.map((category) => (
//                     <Checkbox
//                       key={category.id}
//                       value={category.id}
//                       isChecked={newEvent.categoryIds.includes(category.id)}
//                       onChange={(e) => {
//                         const { checked } = e.target;
//                         setNewEvent((prevEvent) => {
//                           if (checked) {
//                             return {
//                               ...prevEvent,
//                               categoryIds: [
//                                 ...prevEvent.categoryIds,
//                                 category.id,
//                               ],
//                             };
//                           } else {
//                             return {
//                               ...prevEvent,
//                               categoryIds: prevEvent.categoryIds.filter(
//                                 (id) => id !== category.id
//                               ),
//                             };
//                           }
//                         });
//                       }}
//                     >
//                       {category.name}
//                     </Checkbox>
//                   ))}
//                 </FormControl>
//                 <Button type="submit">Add</Button>
//               </form>
//             </ModalBody>
//             <ModalFooter>
//               <Button onClick={handleModalClose}>Cancel</Button>
//             </ModalFooter>
//           </ModalContent>
//         </Modal>
//         <ToastContainer />
//       </>
//     </div>
//   );
// };
